from django.db import models

class Student(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    age = models.IntegerField()
    course = models.CharField(max_length=100)
    # Fields for UI logic
    initials = models.CharField(max_length=5, blank=True)
    color = models.CharField(max_length=50, default="bg-emerald-500")

    def save(self, *args, **kwargs):
        # Automatically generate initials if not provided
        if not self.initials:
            self.initials = "".join([n[0] for n in self.name.split()]).upper()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name